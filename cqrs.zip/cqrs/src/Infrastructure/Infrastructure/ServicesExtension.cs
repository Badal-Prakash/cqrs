using System;
using Microsoft.Extensions.DependencyInjection;

namespace Infrastructure;

public static class ServicesExtension
{

    public static void AddInfrastructure(this IServiceCollection services) { }
}
