using System;
using Microsoft.AspNetCore.Identity;

namespace Persistance.IdentityModels;

public class AppRole:IdentityRole<Guid>
{

}
