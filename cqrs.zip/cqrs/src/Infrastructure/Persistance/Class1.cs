﻿namespace Persistance;

public class Class1
{

}
