using System;

namespace Application.Enum;

public enum Roles
{
    SuperAdmin, Admin, USer, Manager, Basic

}
