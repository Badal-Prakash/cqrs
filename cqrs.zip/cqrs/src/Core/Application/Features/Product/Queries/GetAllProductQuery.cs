using System;
using MediatR;
using Domain.Entities;
using Application.Interfaces;
using Microsoft.EntityFrameworkCore;
using Application.Wrappers;

namespace Application.Features.Product.Queries;

public class GetAllProductQuery : IRequest<ApiResponse<IEnumerable<Domain.Entities.Product>>>
{
    internal class GetAllProductQueryHandler : IRequestHandler<GetAllProductQuery, ApiResponse<IEnumerable<Domain.Entities.Product>>>
    {

        private readonly IAppDbContext _context;
        public GetAllProductQueryHandler(IAppDbContext context)
        {
            _context = context;
        }
        public async Task<ApiResponse<IEnumerable<Domain.Entities.Product>>> Handle(GetAllProductQuery request, CancellationToken cancellationToken)
        {
            var res = await _context.products.ToListAsync(cancellationToken);
            return new ApiResponse<IEnumerable<Domain.Entities.Product>>(res, "Get All Products");
        }
    }
}
