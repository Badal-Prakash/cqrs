using System;
using System.Runtime.CompilerServices;
using FluentValidation.Results;

namespace Application.Exceptions;

public class ValidationErrorException : Exception
{
    public ValidationErrorException() : base("one or More validation errors occurred")
    {
        Errors = new List<string>();
    }
    public List<String> Errors { get; set; }
    public ValidationErrorException(List<ValidationFailure> failure) : this()
    {
        foreach (var item in failure)
        {
            Errors.Add(item.ErrorMessage);
        }
    }
}
