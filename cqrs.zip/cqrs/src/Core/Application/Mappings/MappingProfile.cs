using System;
using Application.Features.Product.Command;
using AutoMapper;

namespace Application.Mappings;

public class MappingProfile : Profile
{
    public MappingProfile()
    {
        CreateMap<CreateProductCommand, Domain.Entities.Product>();
    }
}
