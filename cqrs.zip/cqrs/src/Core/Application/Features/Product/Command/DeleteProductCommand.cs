using System;
using Application.Exceptions;
using Application.Interfaces;
using Application.Wrappers;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace Application.Features.Product.Command;

public class DeleteProductCommand : IRequest<ApiResponse<int>>
{
    public string Name { get; set; }
    public string Description { get; set; }
    public int Rate { get; set; }
    public int Id { get; set; }

    internal class DeleteProductCommandHandler : IRequestHandler<DeleteProductCommand, ApiResponse<int>>
    {
        private readonly IAppDbContext _context;
        public DeleteProductCommandHandler(IAppDbContext context)
        {
            _context = context;
        }
        public async Task<ApiResponse<int>> Handle(DeleteProductCommand request, CancellationToken cancellationToken)
        {
            var product = await _context.products.Where(x => x.Id == request.Id).FirstOrDefaultAsync();
            if (product == null)
            {
                throw new ApiExceptions("Product Not Found");
            }
            _context.products.Remove(product);
            await _context.saveChangesAsync();
            return new ApiResponse<int>(product.Id, "Product Deleted Successfully");
        }
    }
}
