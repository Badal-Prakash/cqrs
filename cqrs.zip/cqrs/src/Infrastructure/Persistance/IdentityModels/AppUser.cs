using System;
using Microsoft.AspNetCore.Identity;

namespace Persistance.IdentityModels;

public class AppUser:IdentityUser<Guid>
{
    public String FirstName { get; set; }
    public String LastName { get; set; }
    public String Gender { get; set; }

}
