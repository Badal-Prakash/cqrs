using Application.DTOS;
using Application.Interfaces;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Persistance.IdentityModels;

namespace Api.Controller
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private readonly IAccountService _accountService;
        public AccountController(IMediator mediator, IAccountService accountService)
        {
            _accountService = accountService;
        }


        [HttpPost("createUser")]
        public async Task<IActionResult> Registeruser(RegisterRequest registerRequest, CancellationToken cancellationToken)
        {
            var result = await _accountService.RegisterUser(registerRequest);
            if (result == null)
            {
                return BadRequest("User already exists with this email");
            }
            return Ok(result);
        }
        [HttpPost("AuthrenticteUser")]
        public async Task<IActionResult> Authruser(AuthRequest authRequest, CancellationToken cancellationToken)
        {
            var result = await _accountService.Authruser(authRequest);
            if (result == null)
            {
                return BadRequest("User does not exists with this email");
            }
            return Ok(result);
        }
        [HttpGet("getAllUsers")]
        public async Task<IActionResult> GetAllUsers(CancellationToken cancellationToken)
        {
            var result = await _accountService.getAllUsers();
            if (result == null)
            {
                return BadRequest("No users found");
            }
            return Ok(result);
        }
    }
}
