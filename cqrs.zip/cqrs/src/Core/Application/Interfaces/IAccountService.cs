using System;
using Application.DTOS;
using Application.Wrappers;

namespace Application.Interfaces;

public interface IAccountService
{
    Task<ApiResponse<Guid>> RegisterUser(RegisterRequest registerRequest);
    // Task<ApiResponse<UserResponse>> getAllUsers();
    Task<ApiResponse<IEnumerable<UserResponse>>> getAllUsers();
    Task<ApiResponse<UserResponse>> Authruser(AuthRequest authRequest);
}
