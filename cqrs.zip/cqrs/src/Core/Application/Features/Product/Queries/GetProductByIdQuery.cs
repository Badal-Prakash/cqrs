using System;
using Application.Exceptions;
using Application.Interfaces;
using Application.Wrappers;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace Application.Features.Product.Queries;

public class GetProductByIdQuery : IRequest<ApiResponse<Domain.Entities.Product>>
{
    public int Id { get; set; }
    internal class GetProductByIdQueryHandler : IRequestHandler<GetProductByIdQuery, ApiResponse<Domain.Entities.Product>>
    {

        private readonly IAppDbContext _context;
        public GetProductByIdQueryHandler(IAppDbContext context)
        {
            _context = context;
        }
        public async Task<ApiResponse<Domain.Entities.Product>> Handle(GetProductByIdQuery request, CancellationToken cancellationToken)
        {
            var res = await _context.products.Where(x => x.Id == request.Id).FirstOrDefaultAsync();
            if (res == null)
            {
                throw new ApiExceptions("Product not found");
            }
            return new ApiResponse<Domain.Entities.Product>(res, "Product found");
        }
    }
}
