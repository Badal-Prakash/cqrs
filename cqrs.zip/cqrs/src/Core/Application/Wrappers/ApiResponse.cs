using System;
using System.Diagnostics;

namespace Application.Wrappers;

public class ApiResponse<T>
{
    public ApiResponse()
    {

    }
    public ApiResponse(T data, string message)
    {
        Succeess = true;
        Message = message;
        Data = data;
    }
    public ApiResponse(string message)
    {
        Succeess = false;
        Message = message;
    }
    public bool Succeess { get; set; }
    public List<String>? Error { get; set; }
    public string? Message { get; set; }
    public T? Data { get; set; }
}
