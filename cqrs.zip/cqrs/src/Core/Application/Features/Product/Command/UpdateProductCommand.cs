using System;
using Application.Exceptions;
using Application.Interfaces;
using Application.Wrappers;
using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace Application.Features.Product.Command;

public class UpdateProductCommand : IRequest<ApiResponse<int>>
{
    public string Name { get; set; }
    public string Description { get; set; }
    public int Rate { get; set; }
    public int Id { get; set; }

    internal class UpdateProductCommandHandler : IRequestHandler<UpdateProductCommand, ApiResponse<int>>
    {
        private readonly IAppDbContext _context;
        private readonly IMapper _mapper;
        public UpdateProductCommandHandler(IAppDbContext context, IMapper mapper)
        {
            _mapper = mapper;
            _context = context;
        }
        public async Task<ApiResponse<int>> Handle(UpdateProductCommand request, CancellationToken cancellationToken)
        {
            var product = await _context.products.Where(x => x.Id == request.Id).FirstOrDefaultAsync();
            // var product = new Domain.Entities.Product();
            if (product == null)
            {
                new ApiExceptions("Product not found");
            }

            product.Name = request.Name;
            product.Description = request.Description;
            product.Rate = request.Rate;
            product.Id = request.Id;

            await _context.saveChangesAsync();

            return new ApiResponse<int>(product.Id, "Product updated successfully");
        }
    }
}
