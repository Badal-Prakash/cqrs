using System;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;
using Persistance.IdentityModels;

namespace Persistance.seeds;

public class DefaultRoles
{
    public async Task SeedRolesAsync(IServiceProvider serviceProvider)
    {
        var roleManager = serviceProvider.GetRequiredService<RoleManager<AppRole>>();
        var roles = new List<AppRole>
        {
            new AppRole { Name = "Admin",NormalizedName = "ADMIN" },
            new AppRole { Name = "User",NormalizedName = "USER" },
            new AppRole { Name = "SuperAdmin", NormalizedName = "SUPERADMIN" },
            new AppRole { Name = "Manager", NormalizedName = "MANAGER" },
            new AppRole { Name = "Basic", NormalizedName = "BASIC" }
        };

        foreach (var role in roles)
        {
            if (!await roleManager.RoleExistsAsync(role.Name))
            {
                await roleManager.CreateAsync(role);
            }
        }
    }
}