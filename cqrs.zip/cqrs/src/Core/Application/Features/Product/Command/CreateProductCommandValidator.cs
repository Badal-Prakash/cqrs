using System;
using FluentValidation;

namespace Application.Features.Product.Command;

public class CreateProductCommandValidator : AbstractValidator<CreateProductCommand>
{
    public CreateProductCommandValidator()
    {
        RuleFor(x => x.Name).NotEmpty().WithMessage("Name is required.");
        RuleFor(x => x.Description).NotEmpty().WithMessage("Description is required.");
        RuleFor(x => x.Rate).GreaterThan(0).WithMessage("Rate must be greater than 0.");
    }
}