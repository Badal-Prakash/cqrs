using System;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;
using Persistance.IdentityModels;

namespace Persistance.seeds;

public class DefaultUser
{
    public async Task SeedUsersAsync(IServiceProvider serviceProvider)
    {
        var roleManager = serviceProvider.GetRequiredService<UserManager<AppUser>>();
        var roles = new List<AppRole>
        {
            new AppRole { Name = "Admin", NormalizedName = "ADMIN" },
            new AppRole { Name = "User", NormalizedName = "USER" },
            new AppRole { Name = "SuperAdmin", NormalizedName = "SUPERADMIN" },
            new AppRole { Name = "Manager", NormalizedName = "MANAGER" },
            new AppRole { Name = "Basic", NormalizedName = "BASIC" }
        };

        var userManager = serviceProvider.GetRequiredService<UserManager<AppUser>>();

        var users = new List<AppUser>
        {
            new AppUser { UserName = "admin@example.com", Email = "admin@example.com", FirstName = "Admin", LastName = "User", PhoneNumber = "1234567890", EmailConfirmed = true, Gender = "Male" },
            new AppUser { UserName = "user@example.com", Email = "user@example.com", FirstName = "Regular", LastName = "User", PhoneNumber = "1234567891", EmailConfirmed = true, Gender = "Female" },
            new AppUser { UserName = "superadmin@example.com", Email = "superadmin@example.com", FirstName = "Super", LastName = "Admin", PhoneNumber = "1234567892", EmailConfirmed = true, Gender = "Male" },
            new AppUser { UserName = "manager@example.com", Email = "manager@example.com", FirstName = "Manager", LastName = "User", PhoneNumber = "1234567893", EmailConfirmed = true, Gender = "Female" },
            new AppUser { UserName = "basic@example.com", Email = "basic@example.com", FirstName = "Basic", LastName = "User", PhoneNumber = "1234567894", EmailConfirmed = true, Gender = "Male" }
        };

        foreach (var user in users)
        {
            var existingUser = await userManager.FindByEmailAsync(user.Email);
            if (existingUser == null)
            {
                var result = await userManager.CreateAsync(user, "Password@123");
                if (result.Succeeded)
                {
                    var role = roles.FirstOrDefault(r => r.Name.Equals(user.FirstName, StringComparison.OrdinalIgnoreCase));
                    if (role != null)
                    {
                        await userManager.AddToRoleAsync(user, role.Name);
                    }
                }
            }
        }
    }
}