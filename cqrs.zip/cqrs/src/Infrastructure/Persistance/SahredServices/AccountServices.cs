using System;
using Application.DTOS;
using Application.Exceptions;
using Application.Interfaces;
using Application.Wrappers;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Persistance.IdentityModels;

namespace Persistance.SahredServices;

public class AccountServices : IAccountService
{

    private readonly UserManager<AppUser> _userManager;
    public AccountServices(UserManager<AppUser> userManager)
    {
        _userManager = userManager;
    }
    public async Task<ApiResponse<Guid>> RegisterUser(RegisterRequest registerRequest)
    {
        var user = _userManager.FindByEmailAsync(registerRequest.Email);
        if (user.Result != null)
        {
            throw new ApiExceptions($"User already exists with this email {registerRequest.Email}");
        }
        var userModel = new AppUser()
        {
            FirstName = registerRequest.FirstName,
            LastName = registerRequest.LastName,
            UserName = registerRequest.UserName,
            Email = registerRequest.Email,
            PhoneNumber = registerRequest.PhoneNumber.ToString(),
            Gender = registerRequest.Gender,

        };
        var result = await _userManager.CreateAsync(userModel, registerRequest.Password);
        if (result.Succeeded)
        {
            return new ApiResponse<Guid>(userModel.Id, "User created successfully");
        }
        else
        {
            throw new ApiExceptions(result.Errors.ToString());
        }
    }

    public async Task<ApiResponse<IEnumerable<UserResponse>>> getAllUsers()
    {
        var users = await _userManager.Users.ToListAsync();
        if (users == null)
        {
            throw new ApiExceptions("No users found");
        }
        var userResponse = users.Select(user => new UserResponse
        {
            Id = user.Id,
            FirstName = user.FirstName,
            LastName = user.LastName,
            UserName = user.UserName,
            Email = user.Email,
            PhoneNumber = user.PhoneNumber,
            Gender = user.Gender
        });

        return new ApiResponse<IEnumerable<UserResponse>>(userResponse, "Users retrieved successfully");
    }

    public async Task<ApiResponse<UserResponse>> Authruser(AuthRequest authRequest)
    {
        var user = await _userManager.FindByEmailAsync(authRequest.Email);
        if (user == null)
        {
            throw new ApiExceptions($"User not found with this email {authRequest.Email}");
        }
        var result = await _userManager.CheckPasswordAsync(user, authRequest.Password);
        if (result)
        {
            return new ApiResponse<UserResponse>(new UserResponse
            {
                Id = user.Id,
                FirstName = user.FirstName,
                LastName = user.LastName,
                UserName = user.UserName ?? string.Empty,
                Email = user.Email ?? string.Empty,
                PhoneNumber = user.PhoneNumber ?? string.Empty
            }, "User authenticated successfully");
        }
        else
        {
            throw new ApiExceptions("Invalid password");
        }
    }
}