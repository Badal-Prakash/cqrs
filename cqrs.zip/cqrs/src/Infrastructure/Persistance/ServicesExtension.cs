using System;
using Application.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Persistance.Context;
using Persistance.IdentityModels;
using Persistance.SahredServices;
using Persistance.seeds;

namespace Persistance;

public static class ServicesExtension
{
    public static void AddPersistance(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddDbContext<AppDbContext>(options => { options.UseSqlServer(configuration.GetConnectionString("DefaultConnection"), b => b.MigrationsAssembly("Persistance")); });
        services.AddIdentityCore<AppUser>().AddRoles<AppRole>().AddEntityFrameworkStores<AppDbContext>();
        services.AddScoped<IAppDbContext, AppDbContext>();
        services.AddTransient<IAccountService, AccountServices>();
        var defaultRoles = new DefaultRoles();
        defaultRoles.SeedRolesAsync(services.BuildServiceProvider()).Wait();
        var defaultUser = new DefaultUser();
        defaultUser.SeedUsersAsync(services.BuildServiceProvider()).Wait();
    }
}
