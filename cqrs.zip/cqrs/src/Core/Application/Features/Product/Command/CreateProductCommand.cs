using System;
using Application.Interfaces;
using Application.Wrappers;
using AutoMapper;
using MediatR;

namespace Application.Features.Product.Command;

public class CreateProductCommand : IRequest<ApiResponse<int>>
{
    public string Name { get; set; }
    public string Description { get; set; }
    public int Rate { get; set; }

    internal class CreateProductCommandHandler : IRequestHandler<CreateProductCommand, ApiResponse<int>>
    {
        private readonly IMapper _mapper;
        private readonly IAppDbContext _context;
        public CreateProductCommandHandler(IAppDbContext context, IMapper mapper)
        {
            _mapper = mapper;
            _context = context;
        }
        public async Task<ApiResponse<int>> Handle(CreateProductCommand request, CancellationToken cancellationToken)
        {
            var product = _mapper.Map<Domain.Entities.Product>(request);

            await _context.products.AddAsync(product);
            await _context.saveChangesAsync();
            return new ApiResponse<int>(product.Id, "Product Created Successfully");
        }
    }
}
