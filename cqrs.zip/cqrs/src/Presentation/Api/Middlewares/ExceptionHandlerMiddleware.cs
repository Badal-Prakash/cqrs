using System;
using System.Net;
using System.Text.Json;
using Application.Exceptions;
using Application.Wrappers;

namespace Api.Middlewares;

public class ExceptionHandlerMiddleware
{
    private readonly RequestDelegate _next;


    public ExceptionHandlerMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (Exception ex)
        {
            var response = context.Response;
            response.ContentType = "application/json";
            var responseModel = new ApiResponse<string>
            {
                Succeess = false,
                Message = ex.Message
            };
            switch (ex)
            {
                case ApiExceptions:
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    break;
                case ValidationErrorException e:
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    responseModel.Error = e.Errors;
                    break;

                default:
                    response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    break;
            }
            var result = JsonSerializer.Serialize(responseModel);
            await response.WriteAsync(result);
        }
    }
}
